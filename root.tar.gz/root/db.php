<?php
$host = "localhost";
$username = "root";
$user_pass = "usbw";
$database_in_use = "vapensa";

// create a database connection instance
$db = new mysqli($host, $username, $user_pass, $database_in_use);

if($db->connect_error) {
    die("IT IS BROKEN");
}

else { echo " Database connection is successful.";} // print out the successful message if connection is successful .

?>