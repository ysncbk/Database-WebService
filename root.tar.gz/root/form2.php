<?php
	include_once 'db.php';
	if($_SERVER['REQUEST_METHOD'] == 'GET') {
    // the entire html below is only output when there's a GET request
?>

<script type="text/javascript">
function displayPopup()
{
 alert("Information has been submitted");
}
</script>

<!DOCTYPE html>
<html>
<head>
	<title>Form Name</title>
	<link rel="stylesheet" type="text/css" href="stylecomp_sales.css">
</head>
<body>
	<nav>
		<div class="navbar">
			<div class="logo">
				<img src="img/logo-vapensa.jpeg">
			</div>
		</div>
		<ul>
			<li><a href="index.html">HOME</a></li>
			<li><a href="#">Forms</a>
			<li class="sub"><a href="#">Internaitonal</a></li>
			<li class="sub"><a href="#">Local</a></li>
			<li><a href="">About</a></li>
		</ul>
	</nav>

<div class="formbox">
<h1>Customer Queries</h1>
	<form class="form_equip">
		<input type="text" name="Client Company Name" placeholder="Client Company Name">
		<select name="Local">
			<option value="Querie">Querie</option>
			<option value="Analysis on All Equipment">Analysis on All Equipment</option>
			
			<option value="Company Equipment with all Info.">Company Equipment with all Info.</option>
				
			<option value="Companies of the Same Equipment">Companies of the Same Equipment</option>
				
			<option value="Comp. of the Same Manufacturer">Comp. of the Same Manufacturer</option>
				
			<option value="Comp. of the Same Cycle Types">Comp. of the Same Cycle Types</option>\s
				
		</select>
		<select name="Month">
			<option value="Month">Month</option>
			<option value="January">January</option>
			<option value="February">February</option>
			<option value="March">March</option>
			<option value="April">April</option>
			<option value="May">May</option>
			<option value="June">June</option>
			<option value="July">July</option>
			<option value="August">August</option>
			<option value="September">September</option>
			<option value="October">October</option>
			<option value="November">November</option>
			<option value="December">December</option>
		</select>
		<select name="Year">
			<option value="2018">2018</option>
		</select>
		<input type="submit" name="Submit">
	</form>
</div>
<form class="footer">
	<div>DISCLAIMER: For each external link existing on this website, we initially have checked that the target page does not contain contents which is illegal wrt. German jurisdiction. However, as we have no in-fluence on such contents, this may change without our notice. Therefore we deny any responsibility for the websites referenced through our external links from here. This website is student lab work and does not necessarily reflect Jacobs University Bremen opinions. Jacobs University Bremen does not endorse this site, nor is it checked by Jacobs University Bremen regularly, nor is it part of the official Jacobs University Bremen web presence.
	</div>
	<div class="disc">
		All rights reserved ® Vapensa 2016 - Vapor y Enfriamiento S.A. <u>e-mail:</u> vapcontact at vapensa.com
	</div>
</form>

<script type="text/javascript"></script>

</body>
</html>


<?php
} else if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Here we handle POST requests
    $client = $_POST['Client Company Name'];
	$Local = $_POST['Local'];
	$Month = $_POST['Month'];
	$Year = $_POST['Year'];


    //  prepared statement.
    $sql1 ="SELECT * FROM EQUIPMENT_COMPANY_ANALYSIS
					LEFT JOIN ANALYST ON EQUIPMENT_COMPANY_ANALYSIS.ID_ANALYST = ANALYST.ID_ANALYST
					LEFT JOIN ANALYST_WORK_LABORATORY ON ANALYST_WORK_LABORATORY.ID_ANALYST = ANALYST.ID_ANALYST
					LEFT JOIN LABORATORY ON ANALYST_WORK_LABORATORY.ID_LABORATORY = LABORATORY.ID_LABORATORY";
	$sql2 = "SELECT * FROM equipment_company as ec
					LEFT JOIN equipment ON ec.id_equipment = equipment.id_equipment
					LEFT JOIN Manufacturing_Equipment ON ec.id_manufacturer = Manufacturing_Equipment.id_manufacturer 
					LEFT JOIN Cycle_Type ON ec.id_cycle_type = Cycle_Type.id_cycle_type";
    
	$sql3 ="SELECT client_company.NAME, equipment_company.equipment FROM client_company, equipment_company
					WHERE equipment_company.ID_CLIENT_COMPANY = client_company.ID_CLIENT_COMPANY
					GROUP BY equipment_company.EQUIPMENT";
	$sql4 ="SELECT client_company.NAME, equipment_company.manufacturer FROM client_company, equipment_company
					WHERE equipment_company.ID_CLIENT_COMPANY = client_company.ID_CLIENT_COMPANY
					GROUP BY EQUIPMENT_COMPANY.manufacturer";
	$sql5  ="SELECT client_company.NAME, equipment_company.cycle_type, cycle_type.id_cycle_type FROM client_company, equipment_company, cycle_type
					WHERE equipment_company.id_cycle_type = cycle_type.id_cycle_type AND equipment_company.ID_CLIENT_COMPANY = client_company.ID_CLIENT_COMPANY
					GROUP BY EQUIPMENT_COMPANY.cycle_type";
    $result1 = $db->query($sql1);
    $result2 = $db->query($sql2);
    $result3 = $db->query($sql3);
    $result4 = $db->query($sql4);
    $result5 = $db->query($sql5);
    
    if ($result1->num_rows > 0) {
    // output data of each row
    while($row = $result1->fetch_assoc()) {
        echo "SEQUENTIAL" . $row["SEQUENTIAL"]."<br>";
    }

} else {
    echo "0 results";
}

    if ($result2->num_rows > 0) {
    // output data of each row
    while($row = $result2->fetch_assoc()) {
        echo "SEQUENTIAL" . $row["SEQUENTIAL"]."<br>";
    }
    
} else {
    echo "0 results";
}

    if ($result3->num_rows > 0) {
    // output data of each row
    while($row = $result3->fetch_assoc()) {
        echo "SEQUENTIAL" . $row["SEQUENTIAL"]."<br>";
    }
    
} else {
    echo "0 results";
}
	if ($result4->num_rows > 0) {
    // output data of each row
    while($row = $result4->fetch_assoc()) {
        echo "SEQUENTIAL" . $row["SEQUENTIAL"]."<br>";
    }
    
} else {
    echo "0 results";
}
	if ($result5->num_rows > 0) {
    // output data of each row
    while($row = $result5->fetch_assoc()) {
        echo "SEQUENTIAL" . $row["SEQUENTIAL"]."<br>";
    }
    
} else {
    echo "0 results";
}

}

if (isset($_POST['Done'])){
    print("<script>window.alert('Information has been submitted');</script>");

}
   
?>
